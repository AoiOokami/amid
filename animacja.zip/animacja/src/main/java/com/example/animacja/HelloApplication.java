package com.example.animacja;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.animation.TranslateTransition;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) {
        Circle circle = new Circle();
        circle.setCenterX(300.0f);
        circle.setCenterY(135.0f);
        circle.setRadius(50.0f);
        circle.setFill(Color.LIGHTBLUE);
        circle.setStrokeWidth(20);
        ScaleTransition scaleTransitionX = new ScaleTransition();
        scaleTransitionX.setDuration(Duration.millis(1000));
        scaleTransitionX.setNode(circle);
        scaleTransitionX.setByX(1.5);
        scaleTransitionX.setCycleCount(50);
        scaleTransitionX.setAutoReverse(true);
        scaleTransitionX.play();
        Group root = new Group(circle);
        Scene scene = new Scene(root, 600, 300);
        stage.setTitle("Animacja kola");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}